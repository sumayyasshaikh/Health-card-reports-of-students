

    import React, { Component } from 'react';
import StudentServices from './StudentServices';
    
    class ListStudentComponent extends Component {

        constructor(){
            super();
            this.state={
                students :[]
            }
        }
        componentDidMount()
        {
            StudentServices.getStudents().then((res)=>{
                this.setState({students: res.data});
            }
            );
        }
        render() {
            return (
                <div>
                    <h2 className="text-center">Health Card Report of Students</h2>
                    <div className="row">
                        <table className="table  table-striped table-bordered">
                            <tbody>
                                <tr>
                                    <th> First Name</th>
                                    <th>Last Name</th>
                                    <th>Email Id</th>
                                    <th>Mobile Number</th>
                                    <th>Address</th>
                                    <th>Aadhar Number</th>
                                    <th>Sugar Level</th>
                                    <th>Blood Group</th>
                                    <th>Any Disease(If yes please specify) </th>
                                </tr>
                            </tbody>
                            <tbody>
                                {
                                    this.state.students.map(
                                        students=>
                                        <tr key={students.id}>
                                        <td> {students.firstName} </td>
                                        <td> {students.lastName} </td>
                                        <td> {students.emailId} </td>
                                        <td> {students.phone} </td>
                                        <td> {students.add} </td>
                                        <td> {students.aadhar} </td>
                                        <td> {students.sl} </td>
                                        <td> {students.bg} </td>
                                        <td> {students.d} </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            );
        }
    }
    
    export default ListStudentComponent;
