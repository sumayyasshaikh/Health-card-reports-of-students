import logo from './logo.svg';
import './App.css';
import ListStudentComponent from './ListStudentComponent';

function App() {
  return (
    <ListStudentComponent />
  );
}

export default App;
